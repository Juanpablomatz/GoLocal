import { createApp } from 'vue'

// importamos Ionic
import { IonicVue } from '@ionic/vue'

// estilos base de Ionic
import '@ionic/vue/css/core.css'
import '@ionic/vue/css/normalize.css'
import '@ionic/vue/css/structure.css'
import '@ionic/vue/css/typography.css'

// opcionales: bonitos
import '@ionic/vue/css/padding.css'
import '@ionic/vue/css/float-elements.css'
import '@ionic/vue/css/text-alignment.css'
import '@ionic/vue/css/text-transformation.css'
import '@ionic/vue/css/flex-utils.css'

import App from './App.vue'
import router from './router'

const app = createApp(App)

// activamos Ionic en tu app ✨
app.use(IonicVue)

// router como siempre
app.use(router)

// montamos la app
router.isReady().then(() => {
  app.mount('#app')
  console.log("📱✨ GoLocal Calvillo ahora está corriendo con Ionic!")
})