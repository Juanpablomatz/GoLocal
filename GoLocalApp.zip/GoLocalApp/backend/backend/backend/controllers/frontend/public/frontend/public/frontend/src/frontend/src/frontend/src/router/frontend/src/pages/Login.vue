<template>
  <ion-page>
    <ion-content class="login-container">

      <ion-card class="login-card">
        <ion-card-header>
          <ion-card-title class="title">
            Iniciar Sesión
          </ion-card-title>
        </ion-card-header>

        <ion-card-content>

          <form @submit.prevent="loginUser">

            <ion-item class="input-group">
              <ion-label position="floating">Correo</ion-label>
              <ion-input 
                type="email" 
                v-model="email" 
                required
              ></ion-input>
            </ion-item>

            <ion-item class="input-group">
              <ion-label position="floating">Contraseña</ion-label>
              <ion-input 
                type="password" 
                v-model="password" 
                required
              ></ion-input>
            </ion-item>

            <ion-button expand="block" class="btn" type="submit">
              Entrar
            </ion-button>

            <p v-if="errorMessage" class="error">{{ errorMessage }}</p>

          </form>

        </ion-card-content>
      </ion-card>

    </ion-content>
  </ion-page>
</template>

<script>
import { 
  IonPage, 
  IonContent, 
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonItem,
  IonInput,
  IonLabel,
  IonButton
} from '@ionic/vue';

export default {
  name: "Login",

  components: {
    IonPage,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonItem,
    IonInput,
    IonLabel,
    IonButton
  },

  data() {
    return {
      email: "",
      password: "",
      errorMessage: ""
    };
  },

  methods: {
    async loginUser() {
      this.errorMessage = "";

      try {
        const response = await fetch("http://localhost:3000/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: this.email,
            password: this.password
          })
        });

        const data = await response.json();

        if (!response.ok) {
          this.errorMessage = data.message || "Credenciales incorrectas.";
          return;
        }

        localStorage.setItem("token", data.token);

        this.$router.push("/home");

      } catch (error) {
        console.error(error);
        this.errorMessage = "Ocurrió un error. Intenta más tarde.";
      }
    }
  }
};
</script>

<style>
.login-container {
  --background: #ffe4ec;
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-card {
  width: 330px;
  border-radius: 16px;
}

.title {
  color: #ff6f91;
  text-align: center;
  font-size: 1.5rem;
}

.input-group {
  margin-bottom: 10px;
}

.btn {
  margin-top: 20px;
  --background: #ff6f91;
  --background-activated: #ff3f70;
  --border-radius: 12px;
  font-weight: bold;
}

.error {
  color: red;
  margin-top: 12px;
  text-align: center;
}
</style>