<template>
  <ion-app>
    <ion-header>
      <ion-toolbar color="light" class="header">
        <img 
          src="/img/GoLocalLogo.png"
          alt="GoLocal Calvillo Logo"
          class="logo"
        />
        <ion-title class="title">
          GoLocal Calvillo
        </ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="app-container">
      <!-- Aquí se cargan las páginas -->
      <router-view />
    </ion-content>
  </ion-app>
</template>

<script>
import { IonApp, IonHeader, IonToolbar, IonTitle, IonContent } from "@ionic/vue";

export default {
  name: "App",
  components: {
    IonApp,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent
  },
};
</script>

<style>
.app-container {
  --background: #fafafa;
  font-family: "Poppins", sans-serif;
  min-height: 100vh;
}

/* Header vibes */
.header {
  display: flex;
  align-items: center;
  gap: 15px;
  background: #ffb3c6 !important;
  border-bottom: 3px solid #ff6f91;
  padding: 10px;
}

.logo {
  height: 40px;
}

.title {
  font-size: 1.4rem;
  font-weight: bold;
  color: #333;
}
</style>