<template>
  <IonApp>
   
    <IonRouterOutlet />
  </IonApp>
</template>

<script>
import { IonApp, IonRouterOutlet } from '@ionic/vue'

export default {
  name: "App",
  components: {
    IonApp,
    IonRouterOutlet
  }
}
</script>

<style>

</style>