<template>
  <ion-page>

    <!-- Encabezado -->
    <ion-header>
      <ion-toolbar class="home-header">
        <ion-title class="title">Bienvenido a GoLocal Calvillo</ion-title>

        <ion-buttons slot="end">
          <ion-button class="logout-btn" @click="logout">
            Cerrar Sesión
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <!-- Contenido principal -->
    <ion-content class="home-container">

      <section class="content">
        <p class="text">
          Aquí es donde comienza la experiencia ✨  
          Muy pronto se mostrarán lugares, rutas, negocios y todo lo especial de Calvillo.
        </p>
      </section>

    </ion-content>

  </ion-page>
</template>

<script>
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonContent
} from "@ionic/vue";

export default {
  name: "Home",

  components: {
    IonPage,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonButton,
    IonContent
  },

  created() {
    const token = localStorage.getItem("token");
    if (!token) {
      this.$router.push("/");
    }
  },

  methods: {
    logout() {
      localStorage.removeItem("token");
      this.$router.push("/");
    }
  }
};
</script>

<style>
.home-container {
  --background: #fff5f8;
  padding: 20px;
  font-family: "Poppins", sans-serif;
}

.home-header {
  background: #ffb3c6;
  border-bottom: 3px solid #ff6f91;
}

.title {
  font-weight: bold;
  color: #4a4a4a;
}

.logout-btn {
  --background: #ff6f91;
  --background-activated: #ff3f70;
  --border-radius: 10px;
  color: white;
  font-weight: bold;
}

.content {
  margin-top: 30px;
}

.text {
  font-size: 1.2rem;
  color: #444;
  line-height: 1.6;
}
</style>