import User from '../models/userModel.js';

export const login = async (req, res) => {
  const { email, password } = req.body;

  // Buscar usuario en la base de datos
  const user = await User.findOne({ email, password });

  if (!user) {
    return res.status(401).json({ msg: 'Credenciales inválidas' });
  }

  res.json({ msg: 'Login exitoso', user });
};